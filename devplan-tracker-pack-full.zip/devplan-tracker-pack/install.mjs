#!/usr/bin/env node

import { copyFile, mkdir, readFile, writeFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import path from "node:path";
import process from "node:process";

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (!arg.startsWith("--")) continue;
    const key = arg.slice(2);
    const value = argv[i + 1];
    if (!value || value.startsWith("--")) out[key] = true;
    else { out[key] = value; i += 1; }
  }
  return out;
}

const args = parseArgs(process.argv.slice(2));
const target = path.resolve(args.target || process.cwd());
const force = Boolean(args.force);
const packRoot = path.dirname(new URL(import.meta.url).pathname);

const files = [
  ["DEVPLAN.md", "DEVPLAN.md"],
  ["DEVPLAN-STATE.json", "DEVPLAN-STATE.json"],
  ["scripts/devplan.mjs", "scripts/devplan.mjs"],
  ["scripts/devplan-status.mjs", "scripts/devplan-status.mjs"],
  ["scripts/devplan-validate.mjs", "scripts/devplan-validate.mjs"],
  ["scripts/devplan-update.mjs", "scripts/devplan-update.mjs"],
  ["scripts/devplan-report.mjs", "scripts/devplan-report.mjs"],
  ["schemas/devplan-state.schema.json", "schemas/devplan-state.schema.json"],
  ["docs/DEVPLAN-USAGE.md", "docs/DEVPLAN-USAGE.md"],
  ["docs/DEVPLAN-GOVERNANCE.md", "docs/DEVPLAN-GOVERNANCE.md"],
  ["docs/DEVPLAN-AGENT-INSTRUCTIONS.md", "docs/DEVPLAN-AGENT-INSTRUCTIONS.md"],
  ["docs/DEVPLAN-CI.md", "docs/DEVPLAN-CI.md"],
  ["docs/DEVPLAN-MIGRATION.md", "docs/DEVPLAN-MIGRATION.md"]
];

async function copyPackFile(source, destination) {
  const from = path.join(packRoot, source);
  const to = path.join(target, destination);
  if (existsSync(to) && !force) { console.log(`skip existing: ${destination}`); return; }
  await mkdir(path.dirname(to), { recursive: true });
  await copyFile(from, to);
  console.log(`installed: ${destination}`);
}

async function updatePackageJson() {
  const packagePath = path.join(target, "package.json");
  if (!existsSync(packagePath)) { console.log("package.json not found; add scripts manually from package-scripts.json"); return; }
  const packageJson = JSON.parse(await readFile(packagePath, "utf8"));
  const snippet = JSON.parse(await readFile(path.join(packRoot, "package-scripts.json"), "utf8"));
  packageJson.scripts ??= {};
  for (const [name, command] of Object.entries(snippet.scripts)) {
    if (!packageJson.scripts[name] || force) packageJson.scripts[name] = command;
  }
  await writeFile(packagePath, `${JSON.stringify(packageJson, null, 2)}\n`);
  console.log("updated package.json scripts");
}

console.log(`Installing DEVPLAN tracker into ${target}`);
for (const [source, destination] of files) await copyPackFile(source, destination);
await updatePackageJson();
console.log("Done. Run: pnpm devplan:validate && pnpm devplan:status");
