# Codex Prompt — Build the DEVPLAN Tracker Repository Properly

You are Codex working in a new dedicated repository for the DEVPLAN Tracker Pack.

## Mission

Create a complete, standalone, production-quality DEVPLAN tracker package and repository from the supplied archive. The result should be useful across any software project, including monorepos, SaaS apps, mobile apps, client websites, and AI-agent-driven repos.

## Source material

Use the archive contents as the starting point. Preserve the concepts, but improve implementation quality wherever appropriate.

The repository should contain:

```text
README.md
LICENSE
package.json
DEVPLAN.md
DEVPLAN-STATE.json
manifest.json
package-scripts.json
schemas/devplan-state.schema.json
scripts/devplan.mjs
scripts/devplan-status.mjs
scripts/devplan-validate.mjs
scripts/devplan-update.mjs
scripts/devplan-report.mjs
install.mjs
docs/DEVPLAN-USAGE.md
docs/DEVPLAN-GOVERNANCE.md
docs/DEVPLAN-AGENT-INSTRUCTIONS.md
docs/DEVPLAN-CI.md
docs/DEVPLAN-MIGRATION.md
docs/CONNECTOR-BLOCKED-SCRIPTS.md
workflows/devplan-check.yml
examples/example.DEVPLAN-STATE.json
tests/devplan-cli.test.mjs
```

## Product requirements

1. Dependency-free CLI preferred. Use only Node built-ins unless a dependency is strongly justified.
2. Node 20+ or 22+ support.
3. CLI must support:
   - `status`
   - `validate`
   - `next`
   - `report`
   - `readiness`
   - `list`
   - `add-milestone`
   - `add-item`
   - `update`
   - `remove-item`
   - `link-item`
   - `protect`
   - `init`
4. Wrapper scripts must work:
   - `devplan-status.mjs`
   - `devplan-validate.mjs`
   - `devplan-update.mjs`
   - `devplan-report.mjs`
5. `install.mjs` must safely install the pack into a target repo.
6. It must not overwrite existing files unless `--force` is provided.
7. It must update `package.json` scripts when available.
8. It must provide manual install instructions for repos without `package.json`.
9. It must validate:
   - state JSON parses
   - schema_version supported
   - project metadata present
   - valid status values
   - unique item IDs
   - milestone item references point to known items
   - items have title, status, priority, success_conditions, updated_at
   - DEVPLAN.md references item IDs
10. It must generate a Markdown report.
11. It must produce a release-readiness result based on blocked and open release-critical items.
12. It must support agent workflows by documenting exact rules for updating state in PRs.

## Repository quality requirements

- Add tests using Node's built-in test runner.
- Add a GitHub Actions workflow that runs tests and devplan validation.
- Add `.gitignore`.
- Add MIT license unless instructed otherwise.
- Add examples for a SaaS project, mobile app, and client website.
- Add a changelog.
- Add clear release instructions.

## Safety and robustness

- Never destroy existing target files without `--force`.
- When modifying package.json, preserve existing scripts.
- Validate user input and return useful errors.
- Keep output readable and grep-friendly.
- Do not require external services.

## Acceptance criteria

Run and pass:

```bash
node scripts/devplan.mjs validate
node scripts/devplan.mjs status
node scripts/devplan.mjs next
node scripts/devplan.mjs report --output /tmp/devplan-report.md
node scripts/devplan.mjs add-milestone --id test-ms --title "Test milestone"
node scripts/devplan.mjs add-item --id test.item --title "Test item" --milestone test-ms --success "Test success"
node scripts/devplan.mjs update --id test.item --status done --note "Completed" --evidence "manual test"
node scripts/devplan.mjs readiness
npm test
```

## Deliverables

- Commit all files.
- Provide a concise final report listing files created, commands run, and test results.
- Do not claim completion unless tests pass.
