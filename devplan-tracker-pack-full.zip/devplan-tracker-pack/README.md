# DEVPLAN Tracker Pack

A dependency-free project progress tracker that can be dropped into any repository.

It creates a durable link between:

- the human plan: `DEVPLAN.md`
- the machine-readable state: `DEVPLAN-STATE.json`
- command-line updates: `scripts/devplan.mjs`
- CI enforcement: `workflows/devplan-check.yml`
- agent behaviour: `docs/AGENT-INSTRUCTIONS.md`

## Why it exists

Projects drift when the plan, the code, the issue tracker, and the release notes all describe different realities. DEVPLAN makes progress explicit. Every meaningful task has an ID. Every task has a status. Every completion should include evidence.

## Quick install

From the pack directory:

```bash
node install.mjs --target /path/to/project
```

Then in the target project:

```bash
pnpm devplan:validate
pnpm devplan:status
```

If the project does not use `pnpm`, use `npm run` or run the Node scripts directly.

## Files installed

```text
DEVPLAN.md
DEVPLAN-STATE.json
scripts/devplan.mjs
scripts/devplan-status.mjs
scripts/devplan-validate.mjs
scripts/devplan-update.mjs
scripts/devplan-report.mjs
schemas/devplan-state.schema.json
docs/DEVPLAN-USAGE.md
docs/DEVPLAN-GOVERNANCE.md
docs/DEVPLAN-AGENT-INSTRUCTIONS.md
docs/DEVPLAN-CI.md
docs/DEVPLAN-MIGRATION.md
```

## Recommended package scripts

See `package-scripts.json`.

## Core commands

```bash
pnpm devplan:validate
pnpm devplan:status
pnpm devplan:next
pnpm devplan:report
pnpm devplan:update -- --id feature.auth --status in_progress --note "Started auth wiring"
pnpm devplan:update -- --id feature.auth --status done --note "Tests pass" --evidence "pnpm test:auth"
node scripts/devplan.mjs add-item --id feature.billing --title "Implement billing" --priority release-critical-now --milestone launch
node scripts/devplan.mjs add-milestone --id launch --title "Launch readiness"
```

## Status values

- `planned`
- `in_progress`
- `done`
- `blocked`
- `deferred`
- `superseded`

## Priority recommendations

- `release-critical-now`
- `must-add-soon-after-release`
- `later-polish`
- `maintenance`

## Governance rule

A pull request that starts, completes, blocks, defers, or supersedes meaningful work should update `DEVPLAN-STATE.json` in the same PR.
