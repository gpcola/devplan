# Project Development Plan

_Last updated: YYYY-MM-DD_

## Purpose

This is the human-readable development plan for this project. `DEVPLAN-STATE.json` is the machine-readable state record.

When work starts, completes, blocks, defers, or becomes superseded, update `DEVPLAN-STATE.json` in the same pull request.

## Commands

```bash
pnpm devplan:status
pnpm devplan:validate
pnpm devplan:next
pnpm devplan:report
pnpm devplan:update -- --id example.first-task --status done --note "Completed"
```

## Current objective

Describe the project objective here.

## Release-critical now

### example.first-task

Objective: replace this example with a real release-critical task.

Success conditions:

- Define a testable outcome.
- Add evidence when complete.

Protected surfaces:

- List anything that must not be broken.

## Must add soon after release

### example.second-task

Objective: replace this example with a near-term task.

## Later polish

### example.polish-task

Objective: replace this example with a non-blocking improvement.

## Update rule

When a development block is completed, update `DEVPLAN-STATE.json` in the same PR.
