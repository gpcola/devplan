# Connector-blocked files from the EV Share repo attempt

During the EV Share repo update, the GitHub connector blocked some writes even though the content was normal project tooling. This archive includes the complete versions.

Previously blocked or partially blocked items:

- `scripts/devplan-status.mjs`
- `scripts/devplan-validate.mjs`
- `scripts/devplan-update.mjs`
- `install.mjs`
- nested usage/governance/CI/agent docs under `tooling/devplan-tracker-pack/docs/`
- fuller schema content under `schemas/devplan-state.schema.json`

This standalone archive contains those files so the dedicated DEVPLAN GitHub repository can be created without the connector limitation.
