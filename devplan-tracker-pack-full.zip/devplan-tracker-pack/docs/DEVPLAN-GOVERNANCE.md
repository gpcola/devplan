# DEVPLAN Governance

## Core rule

A pull request that starts, completes, blocks, defers, or supersedes work must update `DEVPLAN-STATE.json` in the same PR.

## Evidence

Completed work should include evidence. Evidence can be commands, PR numbers, screenshots, docs, release artefacts, or acceptance notes.

## Milestones

Milestones reference item IDs. The CLI recalculates milestone status from item statuses.

## Protected surfaces

Record commands, files, APIs, routes, or behaviours that must not be broken in `rules.protected_surfaces`.
