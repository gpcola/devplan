# Migrating an Existing Project to DEVPLAN

1. Copy the pack into the project.
2. Replace the example plan and state with real project milestones.
3. Add protected surfaces.
4. Add package scripts.
5. Run validation.
6. Make the first PR that includes the initial state file.

Recommended first milestones:

- current-state-audit
- release-critical-now
- post-release
- later-polish
