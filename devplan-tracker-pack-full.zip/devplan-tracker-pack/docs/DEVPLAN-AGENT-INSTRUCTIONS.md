# DEVPLAN Agent Instructions

Before major edits, read `DEVPLAN.md` and `DEVPLAN-STATE.json`.

When starting work, set the relevant item to `in_progress`.

When completing work, set it to `done`, add evidence, and include a note describing what changed.

When work cannot be completed, set it to `blocked` or `deferred` with a concrete reason.

Do not invent green status. If validation was not run, state that in the note.

Do not change protected surfaces unless the plan item explicitly allows it.
