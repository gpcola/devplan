# DEVPLAN CI

Use `workflows/devplan-check.yml` as a GitHub Actions template.

Recommended checks:

- install Node
- run `node scripts/devplan.mjs validate`
- optionally run `node scripts/devplan.mjs readiness` on release branches

For stricter governance, require PRs that change source paths to also change `DEVPLAN-STATE.json`.
