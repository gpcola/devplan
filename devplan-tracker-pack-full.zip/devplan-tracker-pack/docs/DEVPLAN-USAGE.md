# DEVPLAN Usage

## Validate

Run `pnpm devplan:validate` before merging work. Validation checks structure, duplicate IDs, valid statuses, milestone references, and whether item IDs appear in `DEVPLAN.md`.

## Status

Run `pnpm devplan:status` to print milestone and item state.

## Next

Run `pnpm devplan:next` to show unresolved items ordered by priority and status.

## Update

Use `pnpm devplan:update -- --id <id> --status <status> --note "..." --evidence "..."` to update work state.

## Add items

Use `node scripts/devplan.mjs add-item --id <id> --title "Title" --milestone <milestone>`.

## Reports

Use `node scripts/devplan.mjs report --output docs/DEVPLAN-REPORT.md` to generate a Markdown progress report.
