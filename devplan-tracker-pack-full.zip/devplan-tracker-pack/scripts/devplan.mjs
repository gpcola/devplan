#!/usr/bin/env node

import { readFile, writeFile, mkdir, copyFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import path from "node:path";
import process from "node:process";

const statePath = process.env.DEVPLAN_STATE_PATH || "DEVPLAN-STATE.json";
const planPath = process.env.DEVPLAN_PLAN_PATH || "DEVPLAN.md";

function usage() {
  console.log(`DEVPLAN tracker

Commands:
  status
  validate
  next [--limit 5]
  report [--output docs/DEVPLAN-REPORT.md]
  readiness
  list [--status planned]
  add-milestone --id <id> --title <title> [--status planned]
  add-item --id <id> --title <title> [--priority release-critical-now] [--milestone <id>] [--status planned]
  update --id <id> [--status <status>] [--note text] [--evidence text] [--owner name] [--priority value]
  remove-item --id <id>
  link-item --id <id> --milestone <id>
  protect --surface "command or surface"
  init --name "Project" --repo owner/repo --branch main [--force]

Examples:
  node scripts/devplan.mjs status
  node scripts/devplan.mjs next --limit 10
  node scripts/devplan.mjs report --output docs/DEVPLAN-REPORT.md
  node scripts/devplan.mjs add-item --id feature.auth --title "Implement auth" --milestone launch
  node scripts/devplan.mjs update --id feature.auth --status done --note "Tests pass" --evidence "pnpm test:auth"`);
}

function parseArgs(argv) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (!arg.startsWith("--")) { out._.push(arg); continue; }
    const key = arg.slice(2);
    const value = argv[i + 1];
    if (!value || value.startsWith("--")) out[key] = true;
    else { out[key] = value; i += 1; }
  }
  return out;
}

async function loadState() {
  if (!existsSync(statePath)) throw new Error(`${statePath} not found. Run init or install the pack.`);
  return JSON.parse(await readFile(statePath, "utf8"));
}

async function saveState(state) {
  state.project ??= {};
  state.project.updated_at = new Date().toISOString();
  await writeFile(statePath, `${JSON.stringify(state, null, 2)}\n`);
}

function validStatuses(state) {
  return new Set(state.rules?.valid_statuses ?? ["planned", "in_progress", "done", "blocked", "deferred", "superseded"]);
}

function recomputeMilestones(state) {
  for (const milestone of state.milestones ?? []) {
    const milestoneItems = (milestone.items ?? [])
      .map((itemId) => state.items.find((item) => item.id === itemId))
      .filter(Boolean);
    if (!milestoneItems.length) continue;
    if (milestoneItems.some((item) => item.status === "blocked")) milestone.status = "blocked";
    else if (milestoneItems.every((item) => ["done", "deferred", "superseded"].includes(item.status))) milestone.status = "done";
    else if (milestoneItems.some((item) => item.status === "in_progress")) milestone.status = "in_progress";
    else milestone.status = "planned";
  }
}

function byPriorityThenStatus(a, b) {
  const priorityOrder = ["release-critical-now", "must-add-soon-after-release", "later-polish", "maintenance"];
  const statusOrder = ["blocked", "in_progress", "planned"];
  const pa = priorityOrder.includes(a.priority) ? priorityOrder.indexOf(a.priority) : 99;
  const pb = priorityOrder.includes(b.priority) ? priorityOrder.indexOf(b.priority) : 99;
  if (pa !== pb) return pa - pb;
  const sa = statusOrder.includes(a.status) ? statusOrder.indexOf(a.status) : 99;
  const sb = statusOrder.includes(b.status) ? statusOrder.indexOf(b.status) : 99;
  if (sa !== sb) return sa - sb;
  return String(a.id).localeCompare(String(b.id));
}

function printStatus(state) {
  const items = state.items ?? [];
  const counts = new Map();
  for (const item of items) counts.set(item.status, (counts.get(item.status) ?? 0) + 1);
  console.log(`\n${state.project?.name ?? "Project"} development state`);
  console.log(`Repo: ${state.project?.repo ?? "unknown"}`);
  console.log(`Branch: ${state.project?.canonical_branch ?? "unknown"}`);
  console.log(`Updated: ${state.project?.updated_at ?? "unknown"}`);
  console.log("\nStatus counts:");
  for (const status of state.rules?.valid_statuses ?? []) console.log(`- ${status}: ${counts.get(status) ?? 0}`);
  console.log("\nMilestones:");
  for (const milestone of state.milestones ?? []) {
    console.log(`- ${milestone.id}: ${milestone.status} — ${milestone.title}`);
    for (const itemId of milestone.items ?? []) {
      const item = items.find((candidate) => candidate.id === itemId);
      console.log(item ? `  - ${item.id}: ${item.status} — ${item.title}` : `  - ${itemId}: missing`);
    }
  }
}

async function validateState(state) {
  let failures = 0;
  const fail = (message) => { failures += 1; console.error(`✗ ${message}`); };
  const pass = (message) => console.log(`✓ ${message}`);
  if (state.schema_version === 1) pass("schema_version is 1"); else fail("schema_version must be 1");
  if (state.project?.name) pass("project.name present"); else fail("project.name missing");
  if (state.project?.canonical_branch) pass("project.canonical_branch present"); else fail("project.canonical_branch missing");
  if (Array.isArray(state.items)) pass("items array present"); else fail("items array missing");
  if (Array.isArray(state.milestones)) pass("milestones array present"); else fail("milestones array missing");
  const statuses = validStatuses(state);
  const ids = new Set();
  const plan = existsSync(planPath) ? await readFile(planPath, "utf8") : "";
  for (const item of state.items ?? []) {
    if (!item.id) fail("item missing id");
    else if (ids.has(item.id)) fail(`duplicate item id ${item.id}`);
    else ids.add(item.id);
    if (!item.title) fail(`${item.id} missing title`);
    if (!statuses.has(item.status)) fail(`${item.id} invalid status ${item.status}`);
    if (!item.priority) fail(`${item.id} missing priority`);
    if (!Array.isArray(item.success_conditions) || item.success_conditions.length === 0) fail(`${item.id} missing success conditions`);
    if (!item.updated_at) fail(`${item.id} missing updated_at`);
    if (plan && !plan.includes(item.id)) fail(`DEVPLAN.md does not reference ${item.id}`);
  }
  for (const milestone of state.milestones ?? []) {
    if (!milestone.id) fail("milestone missing id");
    if (!Array.isArray(milestone.items)) fail(`milestone ${milestone.id} missing items array`);
    for (const itemId of milestone.items ?? []) if (!ids.has(itemId)) fail(`milestone ${milestone.id} references unknown item ${itemId}`);
  }
  if (failures) process.exit(1);
}

function printNext(state, limit = 5) {
  const unresolved = (state.items ?? [])
    .filter((item) => ["planned", "in_progress", "blocked"].includes(item.status))
    .sort(byPriorityThenStatus)
    .slice(0, limit);
  console.log("\nNext DEVPLAN items:");
  if (!unresolved.length) console.log("No unresolved planned/in-progress/blocked items.");
  for (const item of unresolved) {
    console.log(`- ${item.id} [${item.status}] ${item.priority}: ${item.title}`);
    if (item.notes?.length) console.log(`  note: ${item.notes[item.notes.length - 1]}`);
  }
}

function buildReport(state) {
  const lines = [];
  lines.push(`# ${state.project?.name ?? "Project"} DEVPLAN Report`);
  lines.push("");
  lines.push(`Generated: ${new Date().toISOString()}`);
  lines.push(`Repo: ${state.project?.repo ?? "unknown"}`);
  lines.push(`Branch: ${state.project?.canonical_branch ?? "unknown"}`);
  lines.push("");
  lines.push("## Readiness summary");
  const blockers = (state.items ?? []).filter((item) => item.status === "blocked");
  const criticalOpen = (state.items ?? []).filter((item) => item.priority === "release-critical-now" && !["done", "deferred", "superseded"].includes(item.status));
  lines.push(`- Blocked items: ${blockers.length}`);
  lines.push(`- Open release-critical items: ${criticalOpen.length}`);
  lines.push("");
  lines.push("## Milestones");
  for (const milestone of state.milestones ?? []) lines.push(`- **${milestone.id}** — ${milestone.status} — ${milestone.title}`);
  lines.push("");
  lines.push("## Items");
  for (const item of state.items ?? []) {
    lines.push("");
    lines.push(`### ${item.id}`);
    lines.push(`- Title: ${item.title}`);
    lines.push(`- Status: ${item.status}`);
    lines.push(`- Priority: ${item.priority}`);
    if (item.owner) lines.push(`- Owner: ${item.owner}`);
    if (item.evidence?.length) lines.push(`- Evidence: ${item.evidence.join(", ")}`);
    if (item.success_conditions?.length) lines.push(`- Success: ${item.success_conditions.join("; ")}`);
    if (item.notes?.length) lines.push(`- Latest note: ${item.notes[item.notes.length - 1]}`);
  }
  lines.push("");
  return `${lines.join("\n")}\n`;
}

function printReadiness(state) {
  const blocked = (state.items ?? []).filter((item) => item.status === "blocked");
  const criticalOpen = (state.items ?? []).filter((item) => item.priority === "release-critical-now" && !["done", "deferred", "superseded"].includes(item.status));
  console.log("\nDEVPLAN readiness");
  console.log(`Blocked items: ${blocked.length}`);
  console.log(`Open release-critical items: ${criticalOpen.length}`);
  if (blocked.length || criticalOpen.length) {
    console.log("Result: NOT READY");
    for (const item of [...blocked, ...criticalOpen]) console.log(`- ${item.id} [${item.status}] ${item.title}`);
    process.exitCode = 1;
  } else {
    console.log("Result: READY BY DEVPLAN STATE");
  }
}

async function addMilestone(state, args) {
  if (!args.id || !args.title) throw new Error("add-milestone requires --id and --title");
  if (state.milestones.some((m) => m.id === args.id)) throw new Error(`milestone ${args.id} already exists`);
  state.milestones.push({ id: args.id, title: args.title, status: args.status ?? "planned", items: [] });
  await saveState(state);
  console.log(`Added milestone ${args.id}`);
}

async function addItem(state, args) {
  if (!args.id || !args.title) throw new Error("add-item requires --id and --title");
  if (state.items.some((item) => item.id === args.id)) throw new Error(`item ${args.id} already exists`);
  const now = new Date().toISOString();
  const item = { id: args.id, title: args.title, status: args.status ?? "planned", priority: args.priority ?? "release-critical-now", owner: args.owner ?? "unassigned", evidence: args.evidence ? [args.evidence] : [], success_conditions: args.success ? [args.success] : ["Define success condition"], notes: args.note ? [args.note] : [], updated_at: now };
  if (!validStatuses(state).has(item.status)) throw new Error(`invalid status ${item.status}`);
  state.items.push(item);
  if (args.milestone) {
    const milestone = state.milestones.find((m) => m.id === args.milestone);
    if (!milestone) throw new Error(`milestone ${args.milestone} not found`);
    if (!milestone.items.includes(item.id)) milestone.items.push(item.id);
  }
  recomputeMilestones(state);
  await saveState(state);
  console.log(`Added item ${args.id}`);
}

async function updateItem(state, args) {
  if (!args.id) throw new Error("update requires --id");
  const item = state.items.find((candidate) => candidate.id === args.id);
  if (!item) throw new Error(`item ${args.id} not found`);
  if (args.status) { if (!validStatuses(state).has(args.status)) throw new Error(`invalid status ${args.status}`); item.status = args.status; }
  if (args.owner) item.owner = args.owner;
  if (args.priority) item.priority = args.priority;
  if (args.note) { item.notes ??= []; item.notes.push(args.note); }
  if (args.evidence) { item.evidence ??= []; if (!item.evidence.includes(args.evidence)) item.evidence.push(args.evidence); }
  item.updated_at = new Date().toISOString();
  recomputeMilestones(state);
  await saveState(state);
  console.log(`Updated ${args.id}`);
}

async function removeItem(state, args) {
  if (!args.id) throw new Error("remove-item requires --id");
  const before = state.items.length;
  state.items = state.items.filter((item) => item.id !== args.id);
  if (state.items.length === before) throw new Error(`item ${args.id} not found`);
  for (const milestone of state.milestones ?? []) milestone.items = (milestone.items ?? []).filter((id) => id !== args.id);
  recomputeMilestones(state);
  await saveState(state);
  console.log(`Removed item ${args.id}`);
}

async function linkItem(state, args) {
  if (!args.id || !args.milestone) throw new Error("link-item requires --id and --milestone");
  const item = state.items.find((candidate) => candidate.id === args.id);
  if (!item) throw new Error(`item ${args.id} not found`);
  const milestone = state.milestones.find((candidate) => candidate.id === args.milestone);
  if (!milestone) throw new Error(`milestone ${args.milestone} not found`);
  if (!milestone.items.includes(args.id)) milestone.items.push(args.id);
  recomputeMilestones(state);
  await saveState(state);
  console.log(`Linked ${args.id} to ${args.milestone}`);
}

async function protectSurface(state, args) {
  if (!args.surface) throw new Error("protect requires --surface");
  state.rules ??= {};
  state.rules.protected_surfaces ??= [];
  if (!state.rules.protected_surfaces.includes(args.surface)) state.rules.protected_surfaces.push(args.surface);
  await saveState(state);
  console.log(`Protected surface added: ${args.surface}`);
}

async function initProject(args) {
  if (existsSync(statePath) && !args.force) throw new Error(`${statePath} already exists. Use --force to overwrite.`);
  const name = args.name ?? "New Project";
  const now = new Date().toISOString();
  const state = { schema_version: 1, project: { name, repo: args.repo ?? "owner/repo", canonical_branch: args.branch ?? "main", updated_at: now }, rules: { update_state_when_work_done: true, valid_statuses: ["planned", "in_progress", "done", "blocked", "deferred", "superseded"], protected_surfaces: [] }, milestones: [{ id: "initial", title: "Initial plan", status: "planned", items: ["initial.first-task"] }], items: [{ id: "initial.first-task", title: "Replace with first real task", status: "planned", priority: "release-critical-now", owner: "unassigned", evidence: [], success_conditions: ["Define success condition"], notes: [], updated_at: now }] };
  await writeFile(statePath, `${JSON.stringify(state, null, 2)}\n`);
  if (!existsSync(planPath) || args.force) await writeFile(planPath, `# ${name} Development Plan\n\n## Release-critical now\n\n### initial.first-task\n\nReplace this with the first real task.\n`);
  console.log(`Initialised ${name}`);
}

function listItems(state, args) {
  let items = state.items ?? [];
  if (args.status) items = items.filter((item) => item.status === args.status);
  for (const item of items.sort(byPriorityThenStatus)) console.log(`${item.id}\t${item.status}\t${item.priority}\t${item.title}`);
}

const args = parseArgs(process.argv.slice(2));
const command = args._[0] ?? "status";
try {
  if (command === "init") await initProject(args);
  else {
    const state = await loadState();
    if (command === "status") printStatus(state);
    else if (command === "validate") await validateState(state);
    else if (command === "next") printNext(state, Number(args.limit ?? 5));
    else if (command === "report") { const report = buildReport(state); if (args.output) { await mkdir(path.dirname(args.output), { recursive: true }); await writeFile(args.output, report); console.log(`Wrote ${args.output}`); } else console.log(report); }
    else if (command === "readiness") printReadiness(state);
    else if (command === "list") listItems(state, args);
    else if (command === "add-milestone") await addMilestone(state, args);
    else if (command === "add-item") await addItem(state, args);
    else if (command === "update") await updateItem(state, args);
    else if (command === "remove-item") await removeItem(state, args);
    else if (command === "link-item") await linkItem(state, args);
    else if (command === "protect") await protectSurface(state, args);
    else if (command === "help" || args.help) usage();
    else { usage(); process.exit(1); }
  }
} catch (error) {
  console.error(`DEVPLAN error: ${error.message}`);
  process.exit(1);
}
